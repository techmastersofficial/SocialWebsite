-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2016 at 11:59 AM
-- Server version: 5.5.27-log
-- PHP Version: 5.4.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `socialapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `convo_messages`
--

CREATE TABLE IF NOT EXISTS `convo_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `convo_id` int(50) NOT NULL,
  `msg_by` varchar(50) NOT NULL,
  `msg_content` text NOT NULL,
  `msg_sent` varchar(30) NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `convo_messages`
--

INSERT INTO `convo_messages` (`msg_id`, `convo_id`, `msg_by`, `msg_content`, `msg_sent`) VALUES
(12, 8, 'naeemprasla', 'SGVsbG8gOkQ=', '1:14 am'),
(13, 8, 'naeemprasla', 'SGVsbG8gOkQ=', '9:20 pm');

-- --------------------------------------------------------

--
-- Table structure for table `follow_users`
--

CREATE TABLE IF NOT EXISTS `follow_users` (
  `follow_id` int(9) NOT NULL AUTO_INCREMENT,
  `follow_userone` varchar(50) NOT NULL,
  `follow_usertwo` varchar(50) NOT NULL,
  `follow_on` varchar(50) NOT NULL,
  PRIMARY KEY (`follow_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `follow_users`
--

INSERT INTO `follow_users` (`follow_id`, `follow_userone`, `follow_usertwo`, `follow_on`) VALUES
(8, 'naeemprasla', 'khayyamali', '10:43 pm'),
(9, 'naeemprasla', 'wajihulhassan', '10:43 pm');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE IF NOT EXISTS `post_comments` (
  `com_id` int(9) NOT NULL AUTO_INCREMENT,
  `post_id` varchar(9) NOT NULL,
  `com_by` varchar(50) NOT NULL,
  `com_content` text NOT NULL,
  `com_datentime` varchar(40) NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`com_id`, `post_id`, `com_by`, `com_content`, `com_datentime`) VALUES
(11, '25', 'naeemprasla', 'demo comment', '8:07 pm'),
(12, '25', 'naeemprasla', 'hello world comment', '8:30 pm'),
(13, '25', 'wajihulhassan', 'Nice One ', '8:34 pm'),
(14, '25', 'wajihulhassan', 'keep it up', '8:34 pm');

-- --------------------------------------------------------

--
-- Table structure for table `post_image`
--

CREATE TABLE IF NOT EXISTS `post_image` (
  `image_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE IF NOT EXISTS `post_likes` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` varchar(20) NOT NULL,
  `like_by` varchar(50) NOT NULL,
  PRIMARY KEY (`like_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`like_id`, `post_id`, `like_by`) VALUES
(4, '26', 'naeemprasla'),
(6, '25', 'naeemprasla'),
(7, '25', 'wajihulhassan');

-- --------------------------------------------------------

--
-- Table structure for table `profile_users`
--

CREATE TABLE IF NOT EXISTS `profile_users` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_uname` varchar(30) NOT NULL,
  `user_image` text NOT NULL,
  `user_aboutyou` text NOT NULL,
  `user_gender` varchar(10) NOT NULL,
  `user_bday` varchar(5) NOT NULL,
  `user_bmonth` text NOT NULL,
  `user_byear` varchar(30) NOT NULL,
  `user_city` text NOT NULL,
  `user_country` text NOT NULL,
  `user_update` varchar(30) NOT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `profile_users`
--

INSERT INTO `profile_users` (`profile_id`, `profile_uname`, `user_image`, `user_aboutyou`, `user_gender`, `user_bday`, `user_bmonth`, `user_byear`, `user_city`, `user_country`, `user_update`) VALUES
(6, 'naeemprasla', 'photo.jpg', 'I am Naeem Prasla Website And Software Developer', 'Male', '2', 'Feb', '1992', 'Karachi', 'Pakistan', '11:03 pm 11:06:16'),
(7, 'wajihulhassan', 'photo.jpg', 'Hello Im Wajih', 'Male', '1', 'Jan', '1992', 'Karachi', 'Pakistan', ''),
(8, 'khayyamali', 'photo.jpg', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `register_users`
--

CREATE TABLE IF NOT EXISTS `register_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(30) NOT NULL,
  `user_lname` varchar(30) NOT NULL,
  `user_uname` varchar(30) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_pass` text NOT NULL,
  `user_regdate` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `register_users`
--

INSERT INTO `register_users` (`user_id`, `user_fname`, `user_lname`, `user_uname`, `user_email`, `user_pass`, `user_regdate`) VALUES
(8, 'Naeem', 'Prasla', 'naeemprasla', 'naeemprasla@gmail.com', 'cHJhc2xhOTk=', '10:41 pm 2016/06/11'),
(9, 'Wajih', 'Hassan', 'wajihulhassan', 'wajih@gmail.com', 'cHJhc2xhOTk=', '10:42 pm 2016/06/11'),
(10, 'Khayyam', 'Ali', 'khayyamali', 'khayyam@hotmail.com', 'cHJhc2xhOTk=', '10:42 pm 2016/06/11');

-- --------------------------------------------------------

--
-- Table structure for table `users_posts`
--

CREATE TABLE IF NOT EXISTS `users_posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_by` varchar(40) NOT NULL,
  `post_content` text NOT NULL,
  `post_date` varchar(50) NOT NULL,
  `post_time` varchar(30) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `users_posts`
--

INSERT INTO `users_posts` (`post_id`, `post_by`, `post_content`, `post_date`, `post_time`) VALUES
(25, 'naeemprasla', 'Hello World', ' June 11', '10:44 pm '),
(26, 'wajihulhassan', 'helo elo', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_convo`
--

CREATE TABLE IF NOT EXISTS `user_convo` (
  `convo_id` int(11) NOT NULL AUTO_INCREMENT,
  `convo_userone` varchar(50) NOT NULL,
  `convo_usertwo` varchar(50) NOT NULL,
  `convo_created` varchar(30) NOT NULL,
  PRIMARY KEY (`convo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `user_convo`
--

INSERT INTO `user_convo` (`convo_id`, `convo_userone`, `convo_usertwo`, `convo_created`) VALUES
(8, 'naeemprasla', 'wajihulhassan', '1:14 am'),
(9, 'naeemprasla', 'khayyamali', '8:47 pm');

-- --------------------------------------------------------

--
-- Table structure for table `user_privacy`
--

CREATE TABLE IF NOT EXISTS `user_privacy` (
  `privacy_id` int(9) NOT NULL AUTO_INCREMENT,
  `privacy_uname` varchar(50) NOT NULL,
  `privacy_email` varchar(10) NOT NULL,
  `privacy_dob` varchar(10) NOT NULL,
  `privacy_location` varchar(10) NOT NULL,
  PRIMARY KEY (`privacy_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_privacy`
--

INSERT INTO `user_privacy` (`privacy_id`, `privacy_uname`, `privacy_email`, `privacy_dob`, `privacy_location`) VALUES
(1, 'naeemprasla', 'No', 'No', 'Yes'),
(2, 'wajihulhassan', 'Yes', 'Yes', 'Yes'),
(3, 'khayyamali', 'Yes', 'Yes', 'Yes');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
