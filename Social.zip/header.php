<?php include("admin/database/connectDB.php");?>
<?php include("func/logoutuser.php");?>
<html>
    <head>
        <title>Connect Aptech</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css" />
      
        
    </head>
    <body>
