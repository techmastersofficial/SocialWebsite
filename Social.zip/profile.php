<?php include("homeheader.php");?>
 
<?php if(isset($_COOKIE['username'])) {   
    ?>
  <div class="main-cont-home">
      <?php include("inc/topbar.php");?>
      <div class="main-cont-contentbox">
      <?php   $GET_ID = $_GET['id']; 
      if($GET_ID == $_COOKIE['username'])
      {
          include("inc/my-profile.php");
      }
      else 
      {
          include("inc/user-profile.php");
      }
      ?>

      </div>
      
  </div>  

  <?php 
    
}
else{
header("Location: index.php"); 
}

?>
 


      
  
<?php include("footer.php");?>