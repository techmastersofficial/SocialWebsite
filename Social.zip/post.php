<?php include("homeheader.php");?>
 
<?php if(isset($_COOKIE['username'])) {   
    ?>
  <div class="main-cont-home">
      <?php include("inc/topbar.php"); ?>
      <div class="main-cont-contentbox">
        <?php
            if(isset($_GET['postid']))
            {
              $id =  $_GET['postid'];
                    $getpost = mysql_query("Select * from users_posts where post_id=$id");
                    $countpost = mysql_num_rows($getpost);
                    if($countpost > 0) {
                        $setpost = mysql_fetch_array($getpost);

                        $userpost = $setpost['post_by'];
           	            $getprofile = mysql_query("SELECT * 
                            FROM register_users
                            JOIN profile_users
                            WHERE user_uname = '$userpost'
                            AND profile_uname = '$userpost'");

                            $setuser = mysql_fetch_array($getprofile);
                            $image = $setuser['user_image'];
                            $fullname = $setuser['user_fname']." ".$setuser['user_lname'];
                            $uname = $setuser['user_uname'];
                            $postcontent = $setpost['post_content'];
                            $date = $setpost['post_date']." at ".$setpost['post_time'];
                           
                            ?>
                            <div class="fullpost-box">
                                <div class="post-displaybox">
                                    <div class="post-db-userprofile">
                                        <img src="img/<?php echo $image; ?>" id="profile-pic"/>
                                    </div>
                                    <div class="post-db-userinfo">
                                        <div class="post-user-fname"><a href="profile.php?id=<?php echo $uname; ?>"><?php echo $fullname; ?></a></div>
                                        <div class="pst-datetime"><?php echo $date; ?></div>
                
                                    </div>
                                </div>
                                <div class="post-cont">
                                            <?php echo $postcontent; ?>
                                </div>
                                <?php 
                              $getpostimage = mysql_query("Select * from post_image where post_id=$id");
                              $countimage = mysql_num_rows($getpostimage);
                              if($countimage > 0)
                              {
                                 while($getimages = mysql_fetch_array($getpostimage)){
                                     ?>
                                  <div class="fullpostimages">
                                    <div class="fpimage-box">
                                        <img src="img/<?php echo $getimages['post_image']; ?>" id="profile_pic"/>
                                    </div>
                                    
                                </div>
                                  <?php
                                 }
                                  
                              }
                              else {
                                  echo '';
                              }
                                ?>
                                <br />

 <input type="hidden" id="ptid" value="<?php echo $_GET['postid']; ?>" />
                                <div class="like-commtbox">
                                <script>
                               
                                function checklike(){
                                     var id = $("#ptid").val();
                                    $.ajax({
                                        url:'func/checklike.php',
                                        data:'pid='+id,
                                        success: function(data){
                                            $(".lkcmt").html(data);
                                        }
                                    });
                                }
                                setInterval(function(){ checklike(); }, 400);
                       
                       function like(){
                           var id = $("#ptid").val();
                           $.ajax({
                               url:'func/likepost.php',
                               data:'plid='+id,
                               success: function(data){
                                   $("#sv").html(data);
                               }
                           });
                       }

                        function unlike(){
                            var id = $("#ptid").val();
                           $.ajax({
                               url:'func/unlikepost.php',
                               data:'plid='+id,
                               success: function(data){
                                   $("#sv").html(data);
                               }
                           });
                           
                       }
                                </script>
                                <span id="sv"></span>
                                    <div class="lkcmt">
                                    
                                    </div>

                                    <div class="lkcmt2"><a href="#" id="comment">Write A Comment </a></div>
                                    
                                    <script>
                           function likeprofiles()
                           {
                                var pid = $("#ptid").val();
                                $.ajax({
                                    url:'func/getpostlikes.php',
                                    data:'gplid='+pid,
                                    success: function(data){
                                        $("#getlikes").html(data);
                                    }
                                });
                           }
                           setInterval(function(){ likeprofiles(); }, 1000);
                               

                           function comprofiles()
                           {
                                var pid = $("#ptid").val();
                                $.ajax({
                                    url:'func/getpostcomments.php',
                                    data:'gplid='+pid,
                                    success: function(data){
                                        $("#getcom").html(data);
                                    }
                                });
                           }
                           setInterval(function(){ comprofiles(); }, 1000);    
                            
                            </script>
                                    
                                    <div class="likecomt-count"><div id="getlikes" ></div><div id="getcom"></div></div>
                                </div>
                                <script>
                                $(document).ready(function(){
                                    $(".post-cmtbox").hide();
                                    $("#comment").click(function(){
                                        $(".post-cmtbox").show();
                                    });
                                });
                                </script>


                                 <div class="post-cmtbox">
                                    <table>
                                        <tr>
                                            <td><input type="text" id="cmt-box" placeholder="Write A Comment..." /></td>
                                            <td><button id="btn-comt">Post</button></td>
                                        </tr>
                                    </table>
                                </div>
                               
                                <script>
                                $(document).ready(function(){
                                    $("#btn-comt").click(function(){
                                        var comt = $("#cmt-box").val();
                                        var pstid = $("#ptid").val();
                                        $.ajax({
                                            url:'func/postcomments.php',
                                            data:'cont='+comt+'&psid='+pstid,
                                            success: function(data){
                                                $("#pstcm").html(data);
                                            }
                                        })
                                        $("#cmt-box").val("");
                                    });
                                });
                                </script>
                                <div id="pstcm"></div>





                                
                                <script>
                               function loadcomments(){
                                   var pid = $("#ptid").val();
                                   $.ajax({
                                       url:'func/getcomments.php',
                                       data:'pstid='+pid,
                                       success: function(data){
                                           $(".commentlist").html(data);
                                       }
                                   })
                               }
                                setInterval(function(){ loadcomments(); }, 500);
                                </script>
                                
                        <div class="commentlist">
                                   
                        </div>

                    </div>
                    <div class="fullpost-details">
                          

                            
                            </div>
                    
                            <div class="rightbar-postbox">
                                  
                            
                            </div>
                            <?php

                    }
                    else {
                        echo '404 Not Found';
                    }
            }
            else 
            {
                echo '404 Not Found';
            }
        ?>

      </div>
      
  </div>  

  <?php 
    
}
else{
header("Location: index.php"); 
}

?>
 


      
  
<?php include("footer.php");?>