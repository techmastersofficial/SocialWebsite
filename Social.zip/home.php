<?php include("homeheader.php");?>
 
<?php if(isset($_COOKIE['username'])) {   
    ?>
  <div class="main-cont-home">
      <?php include("inc/topbar.php");?>
      
      <div class="main-cont-contentbox">
  
          
<div class="profile-sidebox">
    
    
    <div class="profile-pic-box">
       <a href="profile.php?id="> <img src="img/photo.jpg" id="profile-pic" /></a>
    </div>
    <div class="updatepicture">
        <a href="#" id="upl-picbox">Change Profile Picture</a>
    </div>
     <script>
        $(document).ready(function(){
            $(".profile-btnupt").hide();
            $("#upl-picbox").click(function(){
                $(".profile-btnupt").show();
            });
             $("#cencel").click(function(){
                $(".profile-btnupt").hide();
            });
            
        });
    </script>
    <br />
                                    
     <div class="profle-menu">
       <div class="user-fullname">Naeem Prasla</div>
        <div class="uname-user">(<a href="profile.php?id=">naeemprasla</a>)</div>
    </div>
    
</div>  
         
      
      
 <div class="profile-content">
     <div class="post-uptbox">
        <br />
        <div class="inp-textarea">
            <textarea type="text" name="status" placeholder="Write Something..." id="statusbox"></textarea>
        </div>
        
        <div class="status-menu">
            <div class="addphoto-btn">
                <i class="fa fa-sm fa-plus ico-ph" aria-hidden="true"></i>
                <input name="filesToUpload[]" id="filesToUpload" class="custom-file-input" type="file" multiple="" />
            </div>
           <div class="btn-box">
               <button type="submit" id="btn-post">Share</button>
           </div>
           <span id="res"></span>
        </div>
       
    </div>
    <script>
            $(document).ready(function(){
                $("#btn-post").click(function(){
                    var status = $("#statusbox").val();
                    if(status == "")
                    {
                        alert("Plz Write Some Text...");
                    }
                    else 
                    {
                       $.ajax({
                        url:'func/poststatus.php?status='+status,
                        success: function(){
                            $("#res").html(data);
                        }
                    })
                    $("#statusbox").val("");
                    }
                    
                    
                });
            });
        </script>
         <script>
        function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("loadposts").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "func/loadallposts.php", true);
  xhttp.send();
}
       $(document).ready(function() {
          
           loadDoc();
       })
        setInterval(function(){ loadDoc(); }, 1000);
    </script>
     <div class="list-postuser">
        <div id="loadposts">
            
        </div>
    </div>
    
    
     
</div>        
  <div class="profile-info">
    <div class="profile-bio">
        <div class="profile-hdtext">Suggestions (<a href="findfriends.php">See all</a>)</div>
     </div>
     <br />
     <div class="profile-bio">
        <div class="profile-hdtext">Ads</div>
                
                    <div class="ads-hd-text"></div>
                    <br />
                    <hr/>
                    
                
            </div>
     </div>
  </div>       
         
         

         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
          
      </div>
  </div>  

  <?php 
    
}
else{
header("Location: index.php"); 
}

?>
 


      
  
<?php include("footer.php");?>