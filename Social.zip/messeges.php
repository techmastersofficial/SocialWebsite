<?php include("homeheader.php");?>
 
<?php if(isset($_COOKIE['username'])) {   
    ?>
  <div class="main-cont-home">
      <?php include("inc/topbar.php");?>
      <div class="main-cont-contentbox">
     
        
      <?php include("inc/conversation.php");?>
      
      <?php include("func/checkconvo.php"); ?>
      <div class="messege-box">
        <?php 
        if(isset($_GET['mid']))
        {
         
          ?>
            <?php 
          $msgusername = $_GET['mid'];
          $setprofile = mysql_query("SELECT * 
            FROM register_users
            JOIN profile_users
            WHERE user_uname =  '$msgusername'
            AND profile_uname =  '$msgusername'");
          $getprofile = mysql_fetch_array($setprofile);
          
          ?>
        <div class="mesg-infobox">
          <div class="conversation-menu">
            <table id="msg-menu-btn">
              <tr>
                <td><a href="#" onclick="newconvo();"><i class="fa fa-plus" aria-hidden="true"></i> New Message </a></td>
                  <td><a href="#" onclick="deleteconvo();"><i class="fa fa-trash" aria-hidden="true"></i> Delete Conversation</a></td>
              </tr>
            </table>
          </div>
          <div class="msg-username"><a href="profile.php?id=<?php echo$msgusername ; ?>"><?php echo $getprofile['user_fname']." ".$getprofile['user_lname'] ;?></a></div>
        </div>
        <script>
    $(doument).ready(function(){
        
    });
</script>
<?php include("inc/getconvodetail.php"); ?>
<script>
  function getconvomsg(){
    var cid= document.getElementById("CID").value;
      var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("demo").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "func/getmsgs.php?cid="+cid, true);
  xhttp.send();
  }

setInterval(function(){ getconvomsg(); }, 1000);
</script>
         <div class="chatmessage-box" id="demo">
            
         </div>
         
          <div class="msg-sendbox">
            <div class="inp-box">
              <input type="text" id="msg-reply" name="reply" Placeholder="Write A Reply..."/>
            </div>

            <div class="btn-replybox">
              <button type="submit" name="btn-reply" id="btn-send">Reply</button>
            </div>
            <span id="res-send"></span>
          </div>
          <script>
            $(document).ready(function(){
              $("#btn-send").click(function(){
                var message = $("#msg-reply").val();
                 var cid= $("#CID").val();
                 if(message == "")
                 {
                   
                 }
                 else
                 {
                   $.ajax({
                     url: 'func/sendmsg.php',
                     data : 'cid='+cid+'&msg='+message,
                     success : function(data) {
                       $("#res-send").html(data);
                     }
                   })
                   $("#msg-reply").val('');
                 }
              });
            });
          </script>
          
          
          <?php
        }
        else
        {
          ?>
          <div class="conv-message"> Select Conversation To Start Chat.</div>
          <?php
        }
        ?>
       
          
      </div>
      
      
        <div class="convo-profilebox">
         
        </div>
         
      
      
      
      </div>
  </div>  

  <?php 
    
}
else{
header("Location: index.php"); 
}

?>
 


      
  
<?php include("footer.php");?>