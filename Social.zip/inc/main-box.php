<div class="border-top">
    <div class="main-box-ind">
        <div class="main-box-welcome">
            
            <div class="welcome-box">
                <div style="margin-top:100px;"></div>
                
                <div class="wc-hd-text">Welcome To Connect </div>
                <div class="wc-para">
                    Connect Aptech Is Online Social Webiste Where All  Can Communicate Each Other
                </div>
                <br />
                <hr />
                
                
            </div>
            <div class="register-box">
                <div class="wc-hd-text">Create An Account Its Free.</div>
                <?php include("func/registeruser.php");?>
                <form method="POST">
                    <table>
                       <tr>
                           <td><input type="text" name="fname" id="reg-inp" placeholder="First Name"/>
                           <input type="text" name="lname" id="reg-inp" placeholder="Last Name"/></td> 
                           
                       </tr>
                       <tr>
                           <td><input type="text" name="username" id="reg-inp-sec" placeholder="Choose Username"/></td>
                       </tr>
                       <tr>
                           <td><input type="email" name="email" id="reg-inp-sec" placeholder="Your Email Address"/></td>
                       </tr>
                       <tr>
                           <td><input type="password" name="pass" id="reg-inp-sec" placeholder="Your Password"/></td>
                       </tr>
                        
                       
                       
                       <tr>
                           <td><br /><button type="submit" name="btn-register" id="bt-register">Register</button></td>
                       </tr>
                       <tr>
                           <td><br /><span id="remtext">By Clicking Register Button You Accept Our Terms Of Use</span></td>
                       </tr>
                    </table>
                </form>
            </div>
           
        </div>
        <br />
        <div class="main-box-wrapp">
            <center>
           <table>
               <tr>
                   <td><div class="dev-info">Developer : <a href="https://www.facebook.com/praslanaeem">Naeem Prasla</a></div></td>
               </tr>
               
           </table>
           <table>
               <tr>
                   <td><span id="cpy-rigths">Connect Aptech &copy; 20<?php echo date("y"); ?> - All Rights Reserved.</span></td>
                  
               </tr>
           </table>
           </center>
        </div>
    </div>
</div>
