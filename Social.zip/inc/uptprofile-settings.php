<?php 
$profileuname = $_COOKIE['username'];
   $getprofile = mysql_query("select * from profile_users where profile_uname='$profileuname'");
   $setprofile = mysql_fetch_array($getprofile);
?>

<div class="account-databox">
    <table id="set-styles">
        <tr>
            <td id="title-style">About You : </td>
            <td id="text-style">
                <div id="abttext"><?php echo $setprofile['user_aboutyou']; ?></div>
                <div id="abtinp">
                    <textarea id="abtuser" cols="30" rows="5"><?php echo $setprofile['user_aboutyou']; ?></textarea>
                </div>
            </td>
             <td id="edit-style">
                <a href="#" id="editabt">Edit</a> 

                <a href="#" id="saveabt"> Save </a>  
                <a href="#" id="cenabt"> Cancel </a>
                
            </td> 
        </tr>
        <script>
        $(document).ready(function(){
                $("#cenabt").hide();
                $("#abtinp").hide();
                $("#saveabt").hide();
            $("#editabt").click(function(){
                $("#editabt").hide();
                $("#cenabt").show();
                $("#saveabt").show();
                $("#abtinp").show();
                $("#abttext").hide();
            });  
            $("#cenabt").click(function(){
                $("#editabt").show();
                $("#cenabt").hide();
                $("#saveabt").hide();
                $("#abtinp").hide();
                $("#abttext").show();
            });
            $("#saveabt").click(function(){
                var abt = $("#abtuser").val();
                $.ajax({
                    url:'func/upt-about.php?abt='+abt,
                    success: function(data){
                        $("#sv-chng2").html(data);
                    }
                })
            });

        });
       
        </script>
        <tr>
        <td id="title-style">Gender : </td>
            <td id="text-style">
                <div id="gentext"><?php echo $setprofile['user_gender']; ?></div>
                <div id="geninp">
                    <select id="gender">
                        <option>Male</option>
                        <option>Fe Male</option>
                    </select>
                </div>
            </td>
             <td id="edit-style">
                <a href="#" id="editgen">Edit</a> 

                <a href="#" id="savegen"> Save </a>  
                <a href="#" id="cengen"> Cancel </a>
                
            </td> 
        </tr>
        <script>
        $(document).ready(function(){
                $("#cengen").hide();
                $("#geninp").hide();
                $("#savegen").hide();
            $("#editgen").click(function(){
                 $("#cengen").show();
                $("#geninp").show();
                $("#savegen").show();
                $("#gentext").hide();
                $("#editgen").hide();
            });
             $("#cengen").click(function(){
                 $("#cengen").hide();
                $("#geninp").hide();
                $("#savegen").hide();
                $("#gentext").show();
                $("#editgen").show();
            });
            $("#savegen").click(function(){
                var gen = $("#gender").val();
                    $.ajax({
                        url:'func/uptgen.php',
                        data: 'gen='+gen,
                        success: function(){
                            $("#sv-chng2").html(data);
                        }

                    });
            });
        })
        </script>
        <tr>
            <td id="title-style">Date Of Birth : </td>
            <td id="text-style">
                <div id="dobtext"><?php echo $setprofile['user_bday']." ".$setprofile['user_bmonth']." ".$setprofile['user_byear']; ?></div>
                <div id="dobinp">
                    <select id="date">
                        <option>1</option>
                        <option>2</option>
                    </select>
                    <select id="month">
                        <option>Jan</option>
                        <option>Feb</option>
                    </select>
                    <select id="year">
                        <option>1992</option>
                        <option>1993</option>
                    </select>
                </div>
            </td>
             <td id="edit-style">
                <a href="#" id="editdob">Edit</a> 

                <a href="#" id="savedob"> Save </a>  
                <a href="#" id="cendob"> Cancel </a>
                
            </td> 
        </tr>
        <script>
            $(document).ready(function(){
                $("#savedob").hide();
                $("#cendob").hide();
                $("#dobinp").hide();
                $("#editdob").click(function(){
                    $("#editdob").hide();
                    $("#savedob").show();
                    $("#cendob").show();
                    $("#dobtext").hide();
                    $("#dobinp").show();
                });
                $("#cendob").click(function(){
                    $("#editdob").show();
                    $("#savedob").hide();
                    $("#cendob").hide();
                    $("#dobtext").show();
                    $("#dobinp").hide();
                });
                $("#savedob").click(function(){
                    var day = $("#date").val();
                    var month = $("#month").val();
                    var year = $("#year").val();

                    $.ajax({
                        url: 'func/uptdob.php',
                        data:'d='+day+'&m='+month+'&y='+year,
                        success: function(data){
                            $("#sv-chng2").html(data);
                        }
                    });

                });
            });
        </script>


        <tr>
            <td id="title-style">Your Location : </td>
            <td id="text-style">
                <div id="loctext"><?php echo $setprofile['user_city'].",".$setprofile['user_country']; ?></div>
                <div id="locinp">
                   <input type="text" id="inpcity" placeholder="City" Value="<?php echo $setprofile['user_city']; ?>"/>
                   <input type="text" id="inpcountry" placeholder="Country" Value="<?php echo $setprofile['user_country']; ?>"/>
                </div>
            </td>
             <td id="edit-style">
                <a href="#" id="editloc">Edit</a> 

                <a href="#" id="saveloc"> Save </a>  
                <a href="#" id="cenloc"> Cancel </a>
                
            </td>
        </tr>
        <script>
        $(document).ready(function(){
                $("#saveloc").hide();
                $("#cenloc").hide();
                $("#locinp").hide();
             $("#editloc").click(function(){
                    $("#saveloc").show();
                    $("#cenloc").show();
                    $("#locinp").show();
                    $("#loctext").hide();
                    $("#editloc").hide();
             }); 
              $("#cenloc").click(function(){
                    $("#saveloc").hide();
                    $("#cenloc").hide();
                    $("#locinp").hide();
                    $("#loctext").show();
                    $("#editloc").show();
             }); 
             $("#saveloc").click(function(){
                var city = $("#inpcity").val();
                var country = $("#inpcountry").val();
                $.ajax({
                    url:'func/uptloc.php',
                    data:'city='+city+'&country='+country,
                    success: function(data){
                        $("#sv-chng2").html(data);
                    }
                });
             }); 

        });
        </script>
         <tr>
            <td id="title-style"></td>
            <td> 
            <div id="sv-chng2"></div>
            </td>            
        </tr>
    </table>
</div>