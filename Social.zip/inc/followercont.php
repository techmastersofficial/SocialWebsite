<script>
    $(document).ready(function(){
    $(".backbox2").hide();
    $(".closebtn2").click(function(){
        $(".backbox2").hide();
    });
     $("#follwers").click(function(){
        $(".backbox2").show();
    });
});
</script>
<div class="backbox2">
    <div class="closebtn2">
            <i class="fa fa-times fa-inverse fa-lg" aria-hidden="true"></i>
     </div>
     <div class="foller-listbox">
         <div class="fl-hd-text">Followers</div>
         <script>
             function loadlflr(){
                    $.ajax({
                        url: 'func/getfollowers.php',
                        success: function(data){
                            $("#loadflg2").html(data)
                        }
                    })
                }
                setInterval(function(){ loadlflr(); }, 1000);

                
             
          </script>
     <div class="loadlist-follng" id="loadflg2">
                
            </div>
     </div>
</div>