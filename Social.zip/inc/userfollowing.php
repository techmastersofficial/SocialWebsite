<script>
    $(document).ready(function(){
    $(".backbox3").hide();
    $(".closebtn3").click(function(){
        $(".backbox3").hide();
    });
     $("#userflg").click(function(){
        $(".backbox3").show();
    });
});
</script>

<div class="backbox3">
    <div class="closebtn3">
            <i class="fa fa-times fa-inverse fa-lg" aria-hidden="true"></i>
     </div>
     <div class="foller-listbox">
         <div class="fl-hd-text">Following</div>
         
         <script>
             function loadluflg(){
                 var id = $("#userflrname").val();
                    $.ajax({
                        url: 'func/userfollowgfunc.php?id='+id,
                        success: function(data){
                            $("#loadflg3").html(data)
                        }
                    })
                }
                setInterval(function(){ loadluflg(); }, 1000);

                
             
          </script>
     <div class="loadlist-follng" id="loadflg3">
                
            </div>
     </div>
</div>