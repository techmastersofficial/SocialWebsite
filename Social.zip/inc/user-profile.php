<?php 
$GetUserName = $_GET['id'];
$getprofile = mysql_query("SELECT * 
FROM register_users
JOIN profile_users
WHERE user_uname =  '$GetUserName'
AND profile_uname =  '$GetUserName'");
$setprofile = mysql_fetch_array($getprofile);
$countuser = mysql_num_rows($getprofile);
if($countuser > 0)
{
    ?>
    <input type="hidden" id="username" value="<?php echo $GetUserName; ?>" />
<div class="profile-sidebox">
    <div class="profile-pic-box">
       <a href="profile.php?id=<?php echo $setprofile['user_uname']; ?>"> <img src="img/<?php echo $setprofile['user_image']; ?>" id="profile-pic" /></a>
    </div>
    <br />
     <div class="profle-menu">
       <div class="user-fullname"><?php echo $setprofile['user_fname']." ".$setprofile['user_lname']; ?></div>
        <div class="uname-user"><a href="profile.php?id=<?php echo $setprofile['user_uname']; ?>">@<?php echo $setprofile['user_uname']; ?></a></div>
    </div>
 <div class="request-box">
     
     <center>
        <script>
            function checkfollow(){
                 var username = document.getElementById('username').value; 
                $.ajax({
                   url: 'func/checkfollow.php',
                   data: 'flchk='+username, 
                   success: function (data){
                       $("#load-text").html(data);
                   }
                });
                
            }
            setInterval(function(){ checkfollow(); }, 1000);
            function unfollowuser()
            {
                var ufid = document.getElementById('username').value; 
                $.ajax({
                   url: 'func/unfollow.php',
                   data: 'ufid='+ufid, 
                   success: function (data){
                       $("#folowcheck").html(data);
                   }
                });
            }
            function followuser()
            {
                var fid = document.getElementById('username').value; 
                $.ajax({
                   url: 'func/follow.php',
                   data: 'fid='+fid, 
                   success: function (data){
                       $("#folowcheck").html(data);
                   }
                });
            }
        </script>
        
        <span id="folowcheck"></span>
        <div id="checkreq">
           
            <div class="btn-link"><span id="load-text"> </span></div>
            <!--<div class="btn-link"><a href="#" onclick="">UnFollow</a></div>-->
            
             <div class="btn-link"><a href="messeges.php?mid=<?php echo $GetUserName; ?>"><i class="fa fa-fw fa-envelope text-inverse"></i> Message</a></div>
        </div>
        
         
     </center>    
 </div>
    
</div>


<div class="profile-content">

    <div class="post-uptbox">
        <br />
        <div class="inp-textarea">
            <textarea type="text" name="status" placeholder="Write Something On <?php echo $setprofile['user_fname']; ?> Wall..." id="statusbox"></textarea>
        </div>
        
        <div class="status-menu">
            <div class="addphoto-btn">
                <i class="fa fa-sm fa-camera ico-ph" aria-hidden="true"></i>
                <input name="filesToUpload[]" id="filesToUpload" class="custom-file-input" type="file" multiple="" />
            </div>
           <div class="btn-box">
               <button type="submit" id="btn-post">Post</button>
           </div>
           <span id="res"></span>
        </div>
        <script>
            $(document).ready(function(){
                $("#btn-post").click(function(){
                    var status = $("#statusbox").val();
                    if(status == "")
                    {
                        alert("Plz Write Some Text...");
                    }
                    else 
                    {
                       $.ajax({
                        url:'func/poststatus.php?status='+status,
                        success: function(){
                            $("#res").html(data);
                        }
                    })
                    $("#statusbox").val("");
                    }
                    
                    
                });
            });
        </script>
    </div>
    <br />
    <script>
   function loaduserposts()
   {
 var username = document.getElementById('username').value;   
           $.ajax({
               url: 'func/loaduserposts.php?pid='+username,
               success : function(data){
                   $("#loadposts").html(data);
               }
           })
   }
   
setInterval(function(){ loaduserposts(); }, 1000);
    </script>
    <div class="list-postuser">
        <div id="loadposts">
            
        </div>
    </div>
</div>
<?php 
$getusername = $_GET['id'];
$getprivacy = mysql_query("select * from user_privacy where privacy_uname='$getusername'");
$setprivacy = mysql_fetch_array($getprivacy);

?>
<div class="profile-info">
    <div class="profile-bio">
    <div class="profile-hdtext"><?php echo $setprofile['user_fname']; ?>'s Profile Info </div>
    <table>
        <tr>
            <td id="tbl-wid"><b>Full Name </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_fname']." ".$setprofile['user_lname']; ?></td>
        </tr>
         <tr>
            <td id="tbl-wid"><b>Username </b> </td>
            <td id="tbl-wid"><a href="profile.php?id=<?php echo $setprofile['user_uname']; ?>">@<?php echo $setprofile['user_uname']; ?></a></td>
        </tr>
        <?php 
        if($setprivacy['privacy_email'] == "Yes")
        {
            
        }
        else
        {
            ?>
            <tr>
                <td id="tbl-wid"><b>Email </b> </td>
                <td id="tbl-wid"><?php echo $setprofile['user_email']; ?></td>
            </tr>
            <?php
        }
        ?>
         
         <tr>
            <td id="tbl-wid"><b>About </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_aboutyou']; ?></td>
        </tr>
        <?php 
        if($setprivacy['privacy_dob'] == "Yes") 
        {
            
        }
        else
        {
            ?>
            <tr>
                <td id="tbl-wid"><b>Birth Date </b> </td>
                <td id="tbl-wid"><?php echo $setprofile['user_bday']." ".$setprofile['user_bmonth']." ".$setprofile['user_byear']; ?></td>
            </tr>
            <?php
        }
        ?>
         <?php 
         if($setprivacy['privacy_location'] == "Yes")
         {
             
         }
         else{
             ?>
              <tr>
                <td id="tbl-wid"><b>Location </b> </td>
                <td id="tbl-wid"><?php echo $setprofile['user_city']." , ".$setprofile['user_country']; ?></td>
            </tr>
             <?php
         }
         ?>
        
    </table>
    
    </div>
    <br />
    <input type="hidden" value="<?php echo $_GET['id'];?>" id="userflrname" />
    <?php include("userfollowing.php");?>
    <div class="profile-frinds">
        <div class="profile-hdtext"><?php echo $setprofile['user_fname']; ?>'s Following (<a href="#" id="userflg">See All</a>)</div>
        <div class="flist-box">
            <div class="ficon-box">
                <img src="img/photo.jpg" id="profile-pic"/>
            </div>
        </div>
    </div>
    <br />
    <?php include("userfollowers.php");?>
     <div class="profile-frinds">
        <div class="profile-hdtext"><?php echo $setprofile['user_fname']; ?>'s Followers (<a href="#" id="userflr">See All</a>)</div>
        <div class="flist-box">
            <div class="ficon-box">
                <img src="img/photo.jpg" id="profile-pic"/>
            </div>
        </div>
    </div>

    
</div>
   
    <?php
}
else {
    echo '<div>This Profile Is UnKnown...</div>';
}
?>
