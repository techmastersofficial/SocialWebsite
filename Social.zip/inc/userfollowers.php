<script>
    $(document).ready(function(){
    $(".backbox4").hide();
    $(".closebtn4").click(function(){
        $(".backbox4").hide();
    });
     $("#userflr").click(function(){
        $(".backbox4").show();
    });
});
</script>

<div class="backbox4">
    <div class="closebtn4">
            <i class="fa fa-times fa-inverse fa-lg" aria-hidden="true"></i>
     </div>
     <div class="foller-listbox">
         <div class="fl-hd-text">Following</div>
         
         <script>
             function loadluflr(){
                 var id = $("#userflrname").val();
                    $.ajax({
                        url: 'func/userfollowerfunc.php?id='+id,
                        success: function(data){
                            $("#loadflg4").html(data)
                        }
                    })
                }
                setInterval(function(){ loadluflr(); }, 1000);

                
             
          </script>
     <div class="loadlist-follng" id="loadflg4">
                
            </div>
     </div>
</div>