<div class="acc-box">
    <br />
    <div class="logo-box">
        <img src="img/logo.png" />
     </div>
    <div class="login-box">
        <br />
        <div class="hd-text">Already A Member? Login Here</div>
        <?php include("func/loginuser.php");?>
        <form method="post">
            <table>
                <tr>
                    <td>
                        <input type="text" name="username" placeholder="Your Username"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="password" name="password" placeholder="Your Password"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="checkbox" name="remme"/><span id="remtext">Remember Me</span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <br />
                        <button type="submit" name="btn-login">Login</button>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>