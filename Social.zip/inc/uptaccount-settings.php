<?php 
$username = $_COOKIE['username'];
$getaccdata = mysql_query("select * from register_users where user_uname='$username' ");
$setaccdata = mysql_fetch_array($getaccdata);
?>
<div class="account-databox">
    <table id="set-styles">
        <tr>
            <td id="title-style">Your Name : </td>
            <td id="text-style">
                <div id="nametext"><?php echo $setaccdata['user_fname']." ".$setaccdata['user_lname']; ?></div>
                <div id="nameinp">
                    <div>
                        <input type="text" Placeholder="First Name"  value="<?php echo $setaccdata['user_fname']; ?>" id="fname-upt"/>
                        <input type="text"  Placeholder="Last Name"  value="<?php echo $setaccdata['user_lname']; ?>" id="lname-upt"/>
                    </div>
                
                </div>
            </td>    
            <td id="edit-style">
                <a href="#" id="editname">Edit</a> 

                <a href="#" id="save-name"> Save </a>  
                <a href="#" id="cen-name"> Cancel </a>
                
            </td>  
            <script>
            $(document).ready(function(){
                $("#nameinp").hide();
                $("#cen-name").hide();
                $("#save-name").hide();

                $("#editname").click(function(){
                        $("#nameinp").show();
                        $("#nametext").hide();
                        $("#editname").hide();
                         $("#cen-name").show();
                         $("#save-name").show();
                });
                 $("#cen-name").click(function(){
                        $("#nametext").show();
                        $("#nameinp").hide();
                        $("#cen-name").hide();
                         $("#editname").show();
                         $("#save-name").hide();
                });

                $("#save-name").click(function(){
                   
                    var fname = $("#fname-upt").val();
                     var lname = $("#lname-upt").val();
                        $.ajax({
                            url: 'func/upt-name.php',
                            data: 'fname='+fname+'&lname='+lname,
                            success: function(data){
                                $("#sv-chng").html(data);
                            }
                        })
                        
                });
            });
            </script>      
        </tr>






        <tr>
            <td id="title-style">Username : </td>
            <td id="text-style">
                <a href="profile.php?id=<?php echo $username; ?>">@<?php echo $setaccdata['user_uname'];?></a> ( You Cannot Edit Username Once It Selected ).
            </td>        
        </tr>






        <tr>
            <td id="title-style">Email Address : </td>
            <td id="text-style">
                <div id="emailtext"><?php echo $setaccdata['user_email']; ?></div>
                <div id="emailinp">
                    <div>
                        <input type="email" Value="<?php echo $setaccdata['user_email']; ?>" id="email-upt"/>
                        
                    </div>
                
                </div>
            
            </td>  
            <td id="edit-style">
                <a href="#" id="editemail">Edit</a> 

                <a href="#" id="save-email"> Save </a>  
                <a href="#" id="cen-email"> Cancel </a>
                
            </td>             
        </tr>
        <Script>
        $(document).ready(function(){
                
                $("#cen-email").hide();
                $("#save-email").hide();
                $("#emailinp").hide();
                $("#editemail").click(function(){
                        
                        $("#editemail").hide();
                         $("#cen-email").show();
                         $("#save-email").show();
                         $("#emailinp").show();
                         $("#emailtext").hide();
                });
                 $("#cen-email").click(function(){
                        
                        $("#cen-email").hide();
                         $("#editemail").show();
                         $("#save-email").hide();
                         $("#emailinp").hide();
                         $("#emailtext").show();
                });

                $("#save-email").click(function(){
                    var email = $("#email-upt").val();
                    $.ajax({
                        url: 'func/upt-email.php',
                        data: 'emailupt='+email,
                        success: function(){
                            $("#sv-chng").html(data);
                        }
                    })
                })
            });
        </script>        




        <tr>
            <td id="title-style">Password </td>
            <td id="text-style">
                 <div id="passtext"><?php echo base64_decode($setaccdata['user_pass']); ?></div>
                <div id="passinp">
                    <div>
                        <input type="password" Value="<?php echo base64_decode($setaccdata['user_pass']); ?>" id="pass-upt"/>
                        
                    </div>
                
                </div>
            </td>    
            <td id="edit-style">
                <a href="#" id="editpass">Edit</a> 

                <a href="#" id="save-pass"> Save </a>  
                <a href="#" id="cen-pass"> Cancel </a>
                
            </td>             
        </tr>
             <Script>
        $(document).ready(function(){
                
                $("#cen-pass").hide();
                $("#save-pass").hide();
                $("#passinp").hide();
                $("#editpass").click(function(){
                        
                        $("#editpass").hide();
                         $("#cen-pass").show();
                         $("#save-pass").show();
                         $("#passinp").show();
                         $("#passtext").hide();
                });
                 $("#cen-pass").click(function(){
                        
                        $("#cen-pass").hide();
                         $("#editpass").show();
                         $("#save-pass").hide();
                         $("#passinp").hide();
                         $("#passtext").show();
                });
                $("#save-pass").click(function(){
                    var pass = $("#pass-upt").val();
                        $.ajax({
                            url: 'func/uptpass.php',
                            data: 'pass='+pass,
                            success : function(data){
                                $("#sv-chng").html(data);
                            }
                        });

                });
            });
        </script>     
        <tr>
            <td id="title-style">Register On : </td>
            <td ><?php echo $setaccdata['user_regdate'];?></td>            
        </tr>
        <tr>
            <td id="title-style"></td>
            <td> <div id="sv-chng"></div></td>            
        </tr>
    </table>
</div>