<div class="setting-sidebar">
    <div class="menu-box">
        <div class="setting-btn" id="account">
            <div class="set-ico"><i class="fa fa-cogs fa-fw fa-lg" aria-hidden="true"></i></div>
            <div class="set-btntext">Account Info</div>
        </div>

        <div class="setting-btn" id="profile">
            <div class="set-ico"><i class="fa fa-fw fa-tasks fa-lg" aria-hidden="true"></i></div>
            <div class="set-btntext">Profile Settings</div>
        </div>


        <div class="setting-btn" id="privacy">
            <div class="set-ico"><i class="fa fa-fw fa-lock fa-lg fa-fw" aria-hidden="true"></i></div>
            <div class="set-btntext">Privacy</div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#profilebox").hide();
    $("#privacybox").hide();

    $("#account").click(function(){
         $("#profilebox").hide();
         $("#privacybox").hide();
         $("#Accountbox").show();
    });

    $("#profile").click(function(){
         $("#Accountbox").hide();
         $("#privacybox").hide();
         $("#profilebox").show();
    });

    $("#privacy").click(function(){
         $("#Accountbox").hide();
         $("#profilebox").hide();
         $("#privacybox").show();
    });
});
</script>