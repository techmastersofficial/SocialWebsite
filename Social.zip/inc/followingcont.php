   <script>
$(document).ready(function(){
    $(".backbox").hide();
    $(".closebtn").click(function(){
        $(".backbox").hide();
    });
     $("#follwngs").click(function(){
        $(".backbox").show();
    });
});
</script>
<div class="backbox">
        <div class="closebtn">
            <i class="fa fa-times fa-inverse fa-lg" aria-hidden="true"></i>
        </div>
        <div class="followng-listbox">
            <div class="fl-hd-text">Following</div>
            <script>
                function loadlflg(){
                    $.ajax({
                        url: 'func/getfollowing.php',
                        success: function(data){
                            $("#loadflg").html(data)
                        }
                    })
                }
                setInterval(function(){ loadlflg(); }, 1000);
                
            </script>
            <div class="loadlist-follng" id="loadflg">
                
            </div>
        </div>
    </div>
    
    