<?php 
$userone = $_GET['mid'];
$usertwo = $_COOKIE['username'];

$getconvo = mysql_query("Select * from user_convo
 where (convo_userone='$userone' And convo_usertwo='$usertwo')
 OR (convo_userone='$usertwo' And convo_usertwo='$userone') ");
 $setconvo = mysql_fetch_array($getconvo);
 
 
?>

<input type="hidden" id="CID" Value="<?php echo $setconvo['convo_id']; ; ?>" />
<input type="hidden" id="MID" Value="<?php echo $_GET['mid'];?>" />
<input type="hidden" id="UID" Value="<?php echo $_COOKIE['username']; ?>" />