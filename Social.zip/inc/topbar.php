<div class="topbar-box">
    <div class="logo-homebox">
        <img src="img/homelogo.png" />
    </div>
    <div class="topbar-searchbox">
        <input type="text" name="search" Placeholder="Search Here" id="search-inp" />
        <script>
          $(document).ready(function(){
                        $("#loadsearch").hide();
                        $("#search-inp").keyup(function(){
                            var search = $("#search-inp").val();
                            if(search == ""){
                                 $("#loadsearch").hide();
                            }
                            else {
                                $("#loadsearch").show();
                                $.ajax({
                                    type:'GET',
                                    url:'func/topbarsearch.php',
                                    data:'srch='+search,
                                    success:function(data){
                                            $("#srch-loadlist").html(data);
                                    }
                                }); 
                            }
                        });
                         
                     }); 
            
        </script>
        <div id="loadsearch">
            <div class="srch-hdtext">Suggestions</div>
            <div id="srch-loadlist">
                
            </div>
        </div>
    </div>
    
    
    
     <div class="topbar-account">
       <a href="profile.php?id=<?php echo $_COOKIE['username']; ?>"> <img src="img/photo.jpg" id="profile-pic" class="roundimg"/></a>
    </div>
    <div class="topbar-menusbox">
        <table>
        <tr>
            <td>
                <div class="tb-menu"><a href="#">
                    <i class="fa fa-fw fa-globe fa-lg text-inverse"></i>
                    <span id="nt-icon">0</span></a>
                </div>
            </td>
           <td>
                <div class="tb-menu"><a href="messeges.php">
                        <i class="fa fa-fw fa-envelope fa-lg text-inverse"></i>
                        <span id="nt-icon">0</span></a>
                </div>
           </td>
            <td><div class="tb-menu"><a href="home.php"><i class="fa fa-fw fa-home text-inverse"></i>Home</a></div></td>
            <td><div class="tb-menu"><a href="settings.php"><i class="fa fa-fw fa-cogs text-inverse"></i>Settings</a></div></td>
            <td><div class="tb-menu"><a href="home.php?logout"><i class="fa fa-fw fa-sign-out text-inverse"></i>Logout</a></div></td>
        </tr>
        </table>
    </div>
   
    
</div>