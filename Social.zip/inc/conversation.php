<div class="convo-listbox">
    <div class="convo-hd-text"> Inbox </div>
 <script>
     function loadconvo(){
          $.ajax({
                url: 'func/loadconversations.php',
                success: function(data){
                    $("#loadconvo").html(data);
                }
            })
     }
    setInterval(function(){ loadconvo(); }, 1000);
    $(document).ready(function(){
       loadconvo(); 
    });
 </script>         
<div id="loadconvo">
    
</div>
</div>