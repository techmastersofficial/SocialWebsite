<?php 
$GetUserName = $_GET['id'];
$getprofile = mysql_query("SELECT * 
FROM register_users
JOIN profile_users
WHERE user_uname =  '$GetUserName'
AND profile_uname =  '$GetUserName'");
$setprofile = mysql_fetch_array($getprofile);
$countuser = mysql_num_rows($getprofile);
if($countuser > 0)
{
    ?>
<div class="profile-sidebox">
     
    
    <div class="profile-pic-box">
       <a href="profile.php?id=<?php echo $setprofile['user_uname']; ?>"> <img src="img/<?php echo $setprofile['user_image']; ?>" id="profile-pic" /></a>
    </div>
    <div class="updatepicture">
        <a href="#" id="upl-picbox">Change Profile Picture</a>
    </div>
    <br />
    <script>
        $(document).ready(function(){
            $(".profile-btnupt").hide();
            $("#upl-picbox").click(function(){
                $(".profile-btnupt").show();
            });
             $("#cencel").click(function(){
                $(".profile-btnupt").hide();
            });
            
        });
    </script>
                           
    <div class="profle-menu">
       <div class="user-fullname"><?php echo $setprofile['user_fname']." ".$setprofile['user_lname']; ?></div>
        <div class="uname-user">(<a href="profile.php?id=<?php echo $setprofile['user_uname']; ?>">@<?php echo $setprofile['user_uname']; ?></a>)</div>
    </div>
    
</div>


<div class="profile-content">
    <div class="post-uptbox">
        <br />
        <div class="inp-textarea">
            <textarea type="text" name="status" placeholder="Write Something..." id="statusbox"></textarea>
        </div>
        
        <div class="status-menu">
            <div class="addphoto-btn">
                <i class="fa fa-sm fa-camera ico-ph" aria-hidden="true"></i>
                <input name="filesToUpload[]" id="filesToUpload" class="custom-file-input" type="file" multiple="" />
            </div>
           <div class="btn-box">
               <button type="submit" id="btn-post">Post</button>
           </div>
           <span id="res"></span>
        </div>
        <script>
            $(document).ready(function(){
                $("#btn-post").click(function(){
                    var status = $("#statusbox").val();
                    if(status == "")
                    {
                        alert("Plz Write Some Text...");
                    }
                    else 
                    {
                       $.ajax({
                        url:'func/poststatus.php?status='+status,
                        success: function(){
                            $("#res").html(data);
                        }
                    })
                    $("#statusbox").val("");
                    }
                    
                    
                });
            });
        </script>
    </div>
    <br />
    <script>
  function loadDoc() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("loadposts").innerHTML = xhttp.responseText;
            }
        };
        xhttp.open("GET", "func/loadposts.php", true);
        xhttp.send();
}
       $(document).ready(function() {
          
           loadDoc();
       });
        setInterval(function(){ loadDoc(); }, 1000);
    </script>
    <div class="list-postuser">
        <div id="loadposts">
            
        </div>
    </div>
</div>

<div class="profile-info">
    <div class="profile-bio">
    <div class="profile-hdtext">Profile Info (<a href="settings.php">Edit</a>)</div>
    <table>
        <tr>
            <td id="tbl-wid"><b>Full Name </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_fname']." ".$setprofile['user_lname']; ?></td>
        </tr>
         <tr>
            <td id="tbl-wid"><b>Username </b> </td>
            <td id="tbl-wid"><a href="profile.php?id=<?php echo $setprofile['user_uname']; ?>">@<?php echo $setprofile['user_uname']; ?></a></td>
        </tr>
         <tr>
            <td id="tbl-wid"><b>Email </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_email']; ?></td>
        </tr>
         <tr>
            <td id="tbl-wid"><b>About </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_aboutyou']; ?></td>
        </tr>
         <tr>
            <td id="tbl-wid"><b>Gender </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_gender']; ?></td>
        </tr>
         <tr>
            <td id="tbl-wid"><b>Birth Date </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_bday']." ".$setprofile['user_bmonth']." ".$setprofile['user_byear']; ?></td>
        </tr>
         <tr>
            <td id="tbl-wid"><b>Location </b> </td>
            <td id="tbl-wid"><?php echo $setprofile['user_city']." , ".$setprofile['user_country']; ?></td>
        </tr>
    </table>
    
    </div>
    <br />
 <?php include("inc/followingcont.php");?>
    <div class="profile-frinds">
        <div class="profile-hdtext">Following (<a href="#" id="follwngs" >See All</a>)</div>
        <div class="flist-box">
            <div class="ficon-box">
                <img src="img/photo.jpg" id="profile-pic" title="Demo User"/>
            </div>
        </div>
    </div>
     
     
    <br />
     <?php include("inc/followercont.php");?>
    <div class="profile-frinds">
        <div class="profile-hdtext">Followers (<a href="#" id="follwers" >See All</a>)</div>
        <div class="flist-box">
            <div class="ficon-box">
                <img src="img/photo.jpg" id="profile-pic" title="Demo User"/>
            </div>
        </div>
    </div>

    
</div>
   
    <?php
}
else {
    echo '<div>This Profile Is UnKnown...</div>';
}
?>
