<?php include("homeheader.php");?>
 
<?php 
if(isset($_COOKIE['username'])) {   
    ?>
  <div class="main-cont-home">
      <?php include("inc/topbar.php"); ?>
      <div class="main-cont-contentbox">
    <div class="main-boxsetting">
       
    <?php include("inc/settingsmenubox.php"); ?>
    <div class="settings-mainbox">

        <div id="Accountbox">
          <div class="setting-hd-text">Account Information</div>
          <?php include("inc/uptaccount-settings.php");?>
        </div>


        <div id="profilebox">
          <div class="setting-hd-text">Profile Settings</div>
          <?php include("inc/uptprofile-settings.php"); ?>
        </div>


        <div id="privacybox">
          <div class="setting-hd-text">Privacy Settings</div>
        </div>





    </div>
    
    
      </div>
  </div>  
</div>
  <?php 
    
}
else{
header("Location: index.php"); 
}

?>
 

  
  
<?php include("footer.php");?>