<?php include("header.php");?>
<div class="main-cont">
   
<?php if(isset($_COOKIE['username'])) {   
    header("Location: home.php"); 
}
else{
?>
   <?php include("inc/account-box.php"); ?>
    <?php include("inc/main-box.php");?>
  
  <?php 
}

?>
 
</div>

      
  
<?php include("footer.php");?>