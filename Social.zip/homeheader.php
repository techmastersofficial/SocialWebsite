<?php include("admin/database/connectDB.php");?>
<?php include("func/logoutuser.php");?>
<html>
    <head>
        <title>Connect Aptech</title>
        <link rel="stylesheet" type="text/css" href="css/styles.css" />
        <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"
    rel="stylesheet" type="text/css">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    
    </head>
    <body>
