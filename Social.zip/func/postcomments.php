<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['cont']) && isset($_GET['psid']))
{
    $user = $_COOKIE['username'];
    $cont = $_GET['cont'];
    $id = $_GET['psid'];
    $date = date("g:i a");

    mysql_query("insert into post_comments 
    (post_id,com_by,com_content,com_datentime) 
    values ('$id','$user','$cont','$date')");

    echo '';
}

?>