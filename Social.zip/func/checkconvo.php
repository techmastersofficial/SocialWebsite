<?php 
if(isset($_GET['mid']))
{
    $userone = $_GET['mid'];
    $usertwo = $_COOKIE['username'];
    $date = date("g:i a");
    
    $Getconvo = mysql_query("Select * from user_convo
     where (convo_userone='$userone' And convo_usertwo='$usertwo') 
     or (convo_userone='$usertwo' And convo_usertwo='$userone')");
     $count_convo = mysql_num_rows($Getconvo);
    if($count_convo > 0)
    {

    }
    else
    {
        mysql_query("insert into user_convo 
        (convo_userone,convo_usertwo,convo_created) 
        values ('$usertwo','$userone','$date')");
    }
}
?>