<?php
include("../admin/database/connectDB.php");
if(isset($_GET['fname']) && isset($_GET['lname']))
{
    $fname = $_GET['fname'];
    $lname = $_GET['lname'];
    $uname = $_COOKIE['username'];

    mysql_query("Update register_users 
    SET user_fname='$fname',user_lname='$lname' 
    Where user_uname='$uname'");

    echo '<span id="alrt-save">Successfully Changed</span>';

    
}
?>