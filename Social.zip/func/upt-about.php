<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['abt']))
{
    $about = $_GET['abt'];
    $uname = $_COOKIE['username'];

    mysql_query("update profile_users set user_aboutyou='$about' where profile_uname='$uname'");

    echo '<span id="alrt-save">Successfully Changed Password</span>';

    
}
?>