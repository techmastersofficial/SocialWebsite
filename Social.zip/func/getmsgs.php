<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['cid']))
{
    $CID = $_GET['cid'];
    
   $getmsg = mysql_query("Select *  from convo_messages where convo_id='$CID' ");
   $countmsg = mysql_num_rows($getmsg);
   if($countmsg > 0)
   {
       while ($setmsg = mysql_fetch_array($getmsg)) {
           
           $userprofile =  $setmsg['msg_by'];
           
          $getprofile = mysql_query("SELECT * 
FROM register_users
JOIN profile_users
WHERE user_uname =  '$userprofile'
AND profile_uname =  '$userprofile'");
           while ($setprofile = mysql_fetch_array($getprofile)) {
               
               
               ?>
               <div class='message'>
                                <div class='img-con'>
                                    <img src='img/<?php echo $setprofile['user_image'];?>' id="profile-pic"/>
                                </div>
                                <div class='text-con'>
                                    <a href='profle.php?id=<?php echo $setprofile['user_uname'];?>'><?php echo $setprofile['user_fname']." ".$setprofile['user_lname'];?></a>
                                    <p id="msg-cont"><?php echo base64_decode($setmsg['msg_content']);?></p>
                                     <p id="datesent"><?php echo $setmsg['msg_sent']; ?></p>
                                </div>
                            </div>
               <?php
           }
           
       }
   }
   else {
       echo '<div class="conv-message"> No Messeges</div>';
   }
}

?>