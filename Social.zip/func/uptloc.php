<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['city']) && isset($_GET['country']))
{
    $city = $_GET['city'];
    $country = $_GET['country'];
    $uname = $_COOKIE['username'];

    mysql_query("update profile_users set user_city='$city',user_country='$country' where profile_uname='$uname'");

    echo '<span id="alrt-save">Successfully Changed Your Location</span>';
}
?>