<?php 
include("../admin/database/connectDB.php");

if(isset($_GET['cid']) && isset($_GET['msg']))
{
  $cid = $_GET['cid'];
   $mesg = base64_encode($_GET['msg']);
   $user = $_COOKIE['username'];
   $date = date("g:i a");
   
   
   mysql_query("insert into convo_messages(convo_id,msg_by,msg_content,msg_sent) 
   Values ('$cid','$user','$mesg','$date')");
   
   echo '';
}
?>