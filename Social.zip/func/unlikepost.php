<?php 
include("../admin/database/connectDB.php");

$username = $_COOKIE['username'];
$id = $_GET['plid'];



mysql_query("delete from post_likes 
where post_id='$id' 
and like_by='$username'");


echo '';
?>