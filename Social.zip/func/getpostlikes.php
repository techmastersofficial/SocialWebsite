<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['gplid']))
{
    $id = $_GET['gplid'];

  $getlikes = mysql_query("select * from post_likes where post_id='$id' ORDER BY like_id DESC");
  $countllikes = mysql_num_rows($getlikes);

?>
<div class="lk-hdtxt">
    <div class="ico-box">
    <i class="fa fa-lg fa-fw fa-thumbs-up" aria-hidden="true"></i> 
    </div>
    <div class="ico-text"><a href="#"><?php echo $countllikes;?></a> </div>
</div>
<?php
  
}
?>


        
