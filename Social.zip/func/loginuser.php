<?php 
if(isset($_POST['btn-login']))
{
    $uname = mysql_real_escape_string($_POST['username']);
    $pass = mysql_real_escape_string($_POST['password']);
    
    $passencrypt = base64_encode($pass);
    if($uname == "" || $pass =="")
    {
        echo '<div class="alertbox">Fill Your Login Creadit</div>';
    }
    else
    {
        
     $checkacc = mysql_query("select * from register_users where user_uname='$uname' and user_pass='$passencrypt'");
    $countuser = mysql_fetch_array($checkacc);
    if($countuser > 0)
    {
        if(isset($_POST['remme']))
        {
           setcookie("username",$uname,time()+(2400*60*60));
           header("Location: home.php");
        }
        else{
           setcookie("username",$uname,time()+(4*60*60));
           header("Location: home.php");
        }
        
    }
    else{
        echo '<div class="alertbox">User Not Exits.</div>';
    }
    }
}
?>