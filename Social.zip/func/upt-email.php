<?php
include("../admin/database/connectDB.php");
if(isset($_GET['emailupt'])) 
{
    $email = $_GET['emailupt'];

    $uname = $_COOKIE['username'];

    mysql_query("Update register_users 
    SET user_email='$email' 
    Where user_uname='$uname'");

    echo '<span id="alrt-save">Successfully Changed Email Address </span>';

    
}
?>