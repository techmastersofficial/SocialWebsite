<?php 
include("../admin/database/connectDB.php");
$userone = $_COOKIE['username'];
$getconvo = mysql_query("select * from user_convo where (convo_userone='$userone') OR (convo_usertwo='$userone') ORDER BY convo_id DESC");
$Countconvo = mysql_num_rows($getconvo);
if($Countconvo > 0)
{
    while ($setconvo = mysql_fetch_array($getconvo)) {
        
     $cuserone = $setconvo['convo_userone'];
     $cusertwo = $setconvo['convo_usertwo'];
     
        if($cuserone == $_COOKIE['username'])
        {
            
       
        $userprfileone = $setconvo['convo_usertwo'];
        $getprofileone = mysql_query("SELECT * FROM register_users JOIN profile_users WHERE user_uname = '$userprfileone' AND profile_uname = '$userprfileone'");
        $setprofileone = mysql_fetch_array($getprofileone);
        
      $Image =  $setprofileone['user_image'];
      $name = $setprofileone['user_fname']." ".$setprofileone['user_lname'];
        ?>
      <a href="messeges.php?mid=<?php echo $userprfileone; ?>">  
          <div class="conv-profilebox">
            <div class="cnvo-profilepic">
                <img src="img/<?php echo $Image; ?>" id="profile-pic" />
            </div>
            <div class="convo-username">
                <div class="convo-name-text"><?php echo $name; ?></div>
            </div>
         <div class="msg-lstdate">Last Seen : <?php echo $setconvo['convo_created'];?></div>
        </div>
        </a>
        <?php
        
        }
        if($cusertwo == $_COOKIE['username'])
        {
            
        $userprfiletwo = $setconvo['convo_userone'];
        $getprofiletwo = mysql_query("SELECT * FROM register_users JOIN profile_users WHERE user_uname = '$userprfiletwo' AND profile_uname = '$userprfiletwo'");
        $setprofiletwo = mysql_fetch_array($getprofiletwo);
        
         $Imagetwo =  $setprofiletwo['user_image'];
        $nametwo = $setprofiletwo['user_fname']." ".$setprofiletwo['user_lname'];
      
      
        ?>
        <a href="messeges.php?mid=<?php echo $userprfiletwo;?>">
        <div class="conv-profilebox">
            <div class="cnvo-profilepic">
                <img src="img/<?php echo $Imagetwo; ?>" id="profile-pic" />
            </div>
            <div class="convo-username">
                <div class="convo-name-text"><?php echo $nametwo; ?></div>
            </div>
        <div class="msg-lstdate">Last Seen : <?php echo $setconvo['convo_created'];?></div>
        </div>
        </a>
        <?php
        
        
        }
     
        
    }
}
else {
    echo 'You Have No Conversations';
}
?>