<?php 
if(isset($_REQUEST['logout']))
{
	setcookie("username","",time()-100);
	header("location: index.php");
}
?>