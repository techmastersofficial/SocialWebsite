<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['fid']))
{
    $userone = $_GET['fid'];
    $usertwo = $_COOKIE['username'];
    $date = date("g:i a");
    
    mysql_query("insert into follow_users (follow_userone,follow_usertwo,follow_on) Values ('$usertwo','$userone','$date')");
}
?>