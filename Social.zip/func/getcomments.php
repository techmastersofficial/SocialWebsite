<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['pstid']))
{
    $pstid = $_GET['pstid'];

 $getcomment = mysql_query("select * from post_comments where post_id='$pstid' ORDER BY com_id DESC ");
while($setcomment = mysql_fetch_array($getcomment)){

$commentuname = $setcomment['com_by'];

           $genprofile = mysql_query("SELECT * FROM register_users JOIN profile_users WHERE user_uname='$commentuname' AND profile_uname='$commentuname'");

                while ($setprofile = mysql_fetch_array($genprofile)) {
                        ?>
                         <div class="usercmt-box">
                                        <div class="usercmt-img">
                                            <img src="img/<?php echo $setprofile['user_image']; ?>" id="profile-pic"/>
                                        </div>
                                        <div class="cmt-profile">
                                            <div class="cmt-usr-name"><a href="profile.php?id=<?php echo $setcomment['com_by']; ?>"><?php echo $setprofile['user_fname']." ".$setprofile['user_lname']; ?></a> </div>
                                            
                                            <div class="cmt-cont-user"><?php  echo $setcomment['com_content']; ?></div>
                                            
                                        </div>
                                    </div>
                        <?php
                }            
}

}
?>