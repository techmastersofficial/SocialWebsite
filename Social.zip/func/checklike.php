<?php 
include("../admin/database/connectDB.php");

$username = $_COOKIE['username'];
$id = $_GET['pid'];

$checklike = mysql_query("select * from post_likes where like_by='$username' AND post_id='$id'");
$countlike = mysql_num_rows($checklike);

if($countlike > 0)
{
    echo '<a href="#" onclick="unlike();">Unlike </a>';
}
else 
{
    echo '<a href="#" onclick="like();">Like </a>';
}
?>