<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['plid']))
{
    $pid = $_GET['plid'];
    $userliked = $_COOKIE['username'];


    mysql_query("insert into post_likes (post_id, like_by) 
    values ('$pid','$userliked')");
    echo 'liked';
}
?>