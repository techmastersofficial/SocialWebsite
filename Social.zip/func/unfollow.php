<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['ufid']))
{
    $userone = $_GET['ufid'];
    $usertwo = $_COOKIE['username'];
    
    mysql_query("delete from follow_users where follow_userone='$usertwo' and follow_usertwo='$userone'");
    
    echo '';
}
?>