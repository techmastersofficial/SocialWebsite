<?php 
include("../admin/database/connectDB.php");

$setpost = mysql_query("select * from users_posts");
while($getallpost = mysql_fetch_array($setpost))
{
    ?>
    
    <?php
}
?>