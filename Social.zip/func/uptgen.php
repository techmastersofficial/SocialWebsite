<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['gen']))
{
    $gender = $_GET['gen'];
    $uname = $_COOKIE['username'];

    mysql_query("update profile_users set user_gender='$gender' where profile_uname='$uname'");

    echo '<span id="alrt-save">Successfully Changed Gender</span>';
  
}
?>