<?php 
include("../admin/database/connectDB.php");

$username = $_COOKIE['username'];
$id = $_GET['plid'];


mysql_query("insert into post_likes 
(post_id,like_by) 
values('$id','$username')");



echo '';
?>