<?php 
include("../admin/database/connectDB.php");

if(isset($_GET['srch']))
{
    $search = $_GET['srch'];
    $GetMe = $_COOKIE['username'];
    
  $getsearch =  mysql_query("Select * from register_users where (user_uname like '%$search%') or (user_fname like '%$search%') ");
$countsearch = mysql_num_rows($getsearch);
if($countsearch > 0)
{
    while ($setsearch = mysql_fetch_array($getsearch)) {
        
      $usernamesearch = $setsearch['user_uname'];
      
  $getprofile = mysql_query("SELECT * 
FROM register_users
JOIN profile_users
WHERE user_uname =  '$usernamesearch'
AND profile_uname =  '$usernamesearch'");
while($setprofile = mysql_fetch_array($getprofile))
{
   $profilepic =  $setprofile['user_image'];
   $fullname = $setprofile['user_fname']." ".$setprofile['user_lname'];
    $userusername = $setprofile['user_uname'];
    ?>
    <div class="srch-profilebox">
        <div class="srch-profilepic">
<a href="profile.php?id=<?php echo $userusername ?>"><img src="img/<?php echo $profilepic; ?>" id="profile-pic" /></a>
        </div>
        <div class="srch-info">
            <div class="sinfo-name"><a href="profile.php?id=<?php echo $userusername ?>"><?php echo $fullname; ?></a></div>
            <div class="sinfo-uname"><a href="profile.php?id=<?php echo $userusername ?>">@<?php echo $userusername ?></a></div>
         </div>
    </div>
    
    
    
    <?php
}

        
    }
}
else 
{
    echo '<div>No Result Found.</div>';
}
}

?>