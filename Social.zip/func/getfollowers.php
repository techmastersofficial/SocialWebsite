<?php 
include("../admin/database/connectDB.php");
$username = $_COOKIE['username'];
$getfolg = mysql_query("select * from follow_users where follow_usertwo='$username'");
$countflr = mysql_num_rows($getfolg);
if($countflr > 0)
{
    ?>
    <div class="conv-message"><?php echo $countflr;?> Followers</div>
    <?php
    while ($setfolg = mysql_fetch_array($getfolg)) {
   $userprofile = $setfolg['follow_userone'];
  $getprofile = mysql_query("SELECT * 
FROM register_users
JOIN profile_users
WHERE user_uname =  '$userprofile'
AND profile_uname =  '$userprofile'");

while ($setprofile = mysql_fetch_array($getprofile)) {
    ?>
    <div class="flg-box">
        <div class="flg-img">
            <img src="img/<?php echo $setprofile['user_image'];?>" id="profile-pic"/>
        </div>
        <div class="flg-info">
            <div class="flg-name"><a href="profile.php?id=<?php echo $setprofile['user_uname'];?>"><?php echo $setprofile['user_fname']." ".$setprofile['user_lname']; ?></a></div>
        </div>
    </div>
    <?php
}

}
}
else{
    echo '<div class="conv-message"> No Followers</div>';
}
?>