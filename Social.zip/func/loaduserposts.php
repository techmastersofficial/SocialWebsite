<?php 
include("../admin/database/connectDB.php");

if(isset($_GET['pid']))
{
    $user_posts = $_GET['pid'];
$GetUserPosts = mysql_query("Select * from users_posts  Where post_by='$user_posts' ORDER BY post_id DESC");
$CountPosts = mysql_num_rows($GetUserPosts);
if($CountPosts > 0)
{
    while ($loaduserpost = mysql_fetch_array($GetUserPosts)) {
       
      $getProfile = $loaduserpost['post_by'];
      
            $getUserProfile = mysql_query("SELECT * 
        FROM register_users
        JOIN profile_users
        WHERE user_uname =  '$getProfile'
        AND profile_uname =  '$getProfile'");

            while ($setUserProfile = mysql_fetch_array($getUserProfile)) {
$postprofileuser = $setUserProfile['user_fname']." ".$setUserProfile['user_lname'] ;
    $postprofileimg = $setUserProfile['user_image'];
    $postcont = $loaduserpost['post_content'];
    $postdate = $loaduserpost['post_date'];
    $time = $loaduserpost['post_time'];
    $postid = $loaduserpost['post_id'];
                   ?>
         <div class="post-box">
       <div class="post-profileimg">
            <div class="img-psts">
                <img src="img/<?php echo $postprofileimg; ?>" id="profile-pic"/>
            </div>
            <div class="post-username"><a href="profile.php?id=<?php echo $getProfile; ?>"><b><?php echo $postprofileuser; ?></b></a></div>
            <div class="post-date"><?php echo $postdate.' at '.$time; ?></div>
       </div>
       <div class="post-content">
       <?php  echo $postcont ?>
       </div>
       <?php 
       $checkphotos = mysql_query("Select * from post_image Where post_id='$postid' LIMIT 3");
       $countphotos = mysql_num_rows($checkphotos);
       if($countphotos > 0)
       {
           ?>
           <div class="post-imagebox">
           <?php
           while($getpics = mysql_fetch_array($checkphotos))
           {
             $PostImage = $getpics['post_image'];
               ?>
           <div class="post-imgbox">
               <img src="img/<?php echo $PostImage; ?>" id="profile-pic" />
           </div>
               
           
           <?php
           }
           ?>
           </div>
           <div><?php 
           $totalphotos = mysql_query("Select * from post_image Where post_id='$postid'");
           $countpho = mysql_num_rows($totalphotos);
           
           echo '<div class="morepics"><a href="post.php?postid='.$postid.'">'.$countpho.' More Photos </a><div>'; 
           
           ?></div>
          <?php
       }
       
    
       else{
           echo '';
       }
       ?>
       
       <div class="post-status">
           <div class="left-pann">
               <span >0 likes </span> | <span> 0 comments | </span> <a href="post.php?postid=<?php echo $postid; ?>" id="pst-optleft">See Full Story </span>
           </div>
            <div class="postlikecmt">
            
           </div>
       </div>
     </div>
       
       
            <?php 
                
            }

    
       
       
       
       
    }
}
else
{
     echo '<div class="pst-alert">This User Have Not Made Any Posts<div>';    
}
}
?>