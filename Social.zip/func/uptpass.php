<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['pass'])) 
{
    $pass = base64_encode($_GET['pass']);

    $uname = $_COOKIE['username'];

    mysql_query("Update register_users 
    SET user_pass='$pass' 
    Where user_uname='$uname'");

    echo '<span id="alrt-save">Successfully Changed Password</span>';

    
}
?>