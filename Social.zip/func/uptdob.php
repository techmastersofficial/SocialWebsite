<?php 
include("../admin/database/connectDB.php");
if(isset($_GET['d']) && isset($_GET['m']) && isset($_GET['y']))
{
    $d = $_GET['d'];
    $m = $_GET['m'];
    $y = $_GET['y'];
    $uname = $_COOKIE['username'];

    mysql_query("update profile_users set user_bday='$d',user_bmonth='$m',user_byear='$y' where profile_uname='$uname'");

    echo '<span id="alrt-save">Successfully Changed Date Of Birth</span>';

    
}
?>