<?php 
if(isset($_POST['btn-register']))
{
    
    $fname = mysql_real_escape_string($_POST['fname']);
    $lname = mysql_real_escape_string($_POST['lname']);
    $uname = mysql_real_escape_string($_POST['username']);
    $email = mysql_real_escape_string($_POST['email']);
    $password = mysql_real_escape_string($_POST['pass']);
    
    $encrypt_passs = base64_encode($password);
    
    $regdate = date('g:i a Y/m/d');
    
    if($fname == "" || $lname == "" || $uname == "" || $email == ""|| $email == "")
    {
        echo '<div class="alertbox">Fill Out All Form Fields</div>';
    }
    else{
        
        $checkuser = mysql_query("select * from register_users where (user_uname='$uname') OR (user_email='$email')" );
        $countuser = mysql_fetch_array($checkuser);
        
        if($countuser > 0)
        {
            echo '<div class="alertbox">User Already Exsist.</div>'; 
        }
        else{
            
            mysql_query("insert into register_users (user_fname,user_lname,user_uname,user_email,user_pass,user_regdate) 
            values ('$fname','$lname','$uname','$email','$encrypt_passs','$regdate')");
            
            mysql_query("insert into profile_users (profile_uname,user_image) 
            values ('$uname','photo.jpg')");
            
            mysql_query("insert into user_privacy (privacy_uname,privacy_email,privacy_dob,privacy_location) 
            values ('$uname','Yes','Yes','Yes')");
            
            setcookie("username",$uname,time()+(4*60*60));
           header("Location: home.php");
            
        }
    }
    
}

?>