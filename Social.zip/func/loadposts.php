<?php 
include("../admin/database/connectDB.php");
$GetPostUser = $_COOKIE['username'];
$getpost = mysql_query("Select * from users_posts  Where post_by='$GetPostUser' ORDER BY post_id DESC");
$countpost = mysql_num_rows($getpost);
if($countpost > 0)
{
  
  while ($setposts =  mysql_fetch_array($getpost)) {
$postuser = $setposts['post_by'];
    
  $postuserprofile = mysql_query("SELECT * 
FROM register_users
JOIN profile_users
WHERE user_uname =  '$postuser'
AND profile_uname =  '$postuser'");
while ($setpostprofile = mysql_fetch_array($postuserprofile)) {
    
          
    $postprofileuser = $setpostprofile['user_fname']." ".$setpostprofile['user_lname'] ;
    $postprofileimg = $setpostprofile['user_image'];
    $postcont = $setposts['post_content'];
    $postdate = $setposts['post_date'];
    $time = $setposts['post_time'];
    $postid = $setposts['post_id'];
    
     ?>
     <div class="post-box">
       <div class="post-profileimg">
            <div class="img-psts">
                <img src="img/<?php echo $postprofileimg; ?>" id="profile-pic"/>
            </div>
            <div class="post-username"><a href="profile.php?id=<?php echo $postuser; ?>"><b><?php echo $postprofileuser; ?></b></a></div>
            <div class="post-date"><?php echo $postdate.' at '.$time; ?></div>
       </div>
       <div class="post-content">
       <?php  echo $postcont; ?>
       </div>
       <?php 
       $checkphotos = mysql_query("Select * from post_image Where post_id='$postid' LIMIT 3");
       $countphotos = mysql_num_rows($checkphotos);
       if($countphotos > 0)
       {
           ?>
           <div class="post-imagebox">
           <?php
           while($getpics = mysql_fetch_array($checkphotos))
           {
             $PostImage = $getpics['post_image'];
               ?>
           <div class="post-imgbox">
               <img src="img/<?php echo $PostImage; ?>" id="profile-pic" />
           </div>
               
           
           <?php
           }
           ?>
           </div>
           <div><?php 
           $totalphotos = mysql_query("Select * from post_image Where post_id='$postid'");
           $countpho = mysql_num_rows($totalphotos);
           
           echo '<div class="morepics"><a href="post.php?postid='.$postid.'">'.$countpho.' More Photos </a><div>'; 
           
           ?></div>
          <?php
       }
       
    
       else{
           echo '';
       }
       ?>
       
       <div class="post-status">
         <div id="lk-flt"></div>
        
           <div class="left-pann">
                <div class="lk-hdtxt">
                    <div class="ico-box">
                    <i class="fa fa-lg fa-fw fa-thumbs-up" aria-hidden="true"></i> 
                    </div>
                    <div class="ico-text"><a href="#">0</a> </div>
                </div>
                <div class="lk-hdtxt">
                    <div class="ico-box">
                    <i class="fa fa-lg fa-fw fa-comment" aria-hidden="true"></i> 
                    </div>
                    <div class="ico-text"><a href="#">0</a> </div>
                </div>
            
              <a href="post.php?postid=<?php echo $setposts['post_id']; ?>">View This Post </a> 
           </div>
        

           <div class="postlikecmt">
               <div class="likecomt-count"><div id="getlikes" ><a href="#" onclick="">like </a></div><div id="getcom"><a href="#" onclick="">Comments </a></div></div>
           </div>
       </div>
       <br />
     </div>
     
  <?php
}


    
  }
  
}
else
{
    echo '<div class="pst-alert">You Have Not Made Any Posts<div>';    
}

?>