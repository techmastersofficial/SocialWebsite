<?php 
include("../admin/database/connectDB.php");

if(isset($_GET['flchk']))
{
    $userone = $_GET['flchk'];
    $usertwo = $_COOKIE['username'];
    
    $GetFollow = mysql_query("Select * from follow_users Where follow_userone='$usertwo' And follow_usertwo='$userone'");
   $countFollow = mysql_num_rows($GetFollow);
   if($countFollow > 0)
   {
       echo '<a href="#" onclick="unfollowuser();"><i class="fa fa-fw fa-check text-inverse"></i> Un follow</a>';
   }
   else 
   {
       echo '<a href="#" onclick="followuser();"><i class="fa fa-fw fa-rss text-inverse"></i> Follow</a>';
   }
   
}
?>