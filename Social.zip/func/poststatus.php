<?php 
include("../admin/database/connectDB.php");

if(isset($_GET['status']))
{
    $status = $_GET['status'];
    $userby = $_COOKIE['username'];
    $updated = date(" F d");
    $time = date("g:i a ");
    
    mysql_query("insert into users_posts (post_by,post_content,post_date,post_time) 
    Values ('$userby','$status','$updated','$time')");
     echo '';
}
?>